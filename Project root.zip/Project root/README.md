# Gefari Laravel Project

Browser-only GitHub Upload Ready.

This project is for Gefari Detective & Law Center. It includes:

- Controllers
- Routes
- Views (Blade templates)
- composer.json & package.json
- .gitignore
