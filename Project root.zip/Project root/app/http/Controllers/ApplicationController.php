<?php
namespace App\Http\Controllers;

class ApplicationController {
    public function create() {
        return view('apply');
    }
}
